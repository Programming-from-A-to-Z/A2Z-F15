Array.prototype.choice = function() {
  var r = floor(random(this.length));
  return this[r];  
}

var txt = "It was a dark and stormy night. Really really dark and stormy I know it was very much very very much. thank you.";

var ngrams = [];

var markov = { };

var n = 3;

function setup() {
  noCanvas();

  for (var i = 0; i <= txt.length - n; i++) {
    var gram = txt.substring(i, i + n);
    
    if (!markov[gram]) {
      markov[gram] = [];
      ngrams.push(gram);
    }

    markov[gram].push(txt.charAt(i+n));
     //ngrams.push(gram);
  }



}

function mousePressed() {
  //createP(ngrams.choice());

  var count = 0;
  var maximum = 100;

  var start = ngrams.choice();

  while (count < maximum) {
    var len = start.length;
    var possibilities = markov[start.substring(len-n, len)];
    var next = possibilities.choice();

    start = start + next;
    count++;
  }

  createP(start);

}





