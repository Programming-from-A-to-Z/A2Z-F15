var bubble = {
  x: 100,
  y: 100
}

var bubble2;

function setup() {
  createCanvas(400, 300);

  bubble2 = Object.create(bubble);
}

function draw() {
  background(0);
  ellipse(bubble.x, bubble.y, 16, 16);
  ellipse(bubble2.x, bubble2.y, 16, 16);
}