function Bubble(x, y) {
  this.x = x;
  this.y = y;
}

Bubble.prototype.display = function() {
  ellipse(this.x, this.y, 16, 16);
}


Bubble.prototype.move = function() {
  this.x += random(-2, 2);
}


var bubble, bubble2;

function setup() {
  createCanvas(400, 300);
  bubble = new Bubble(100, 200);
  bubble2 = new Bubble(200, 200);
}

function draw() {
  background(0);
  ellipse(bubble.x, bubble.y, 16, 16);
  ellipse(bubble2.x, bubble2.y, 16, 16);
}