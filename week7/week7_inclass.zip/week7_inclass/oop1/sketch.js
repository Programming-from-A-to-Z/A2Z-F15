var letters = ['a', 'a', 'b'];
var nums = [91, 1, 5, 4, 5, 7, 7, 7];

function setup() {
  // console.log(choice(letters));
  // console.log(choice(nums));
  console.log(letters.choice());
  console.log(nums.choice());
}

Array.prototype.choice = function() {
  var r = floor(random(this.length));
  return this[r];  
}

// function choice(arr) {
//   var r = floor(random(arr.length));
//   return arr[r];
// }
 


// var bubble = {
//   x: 100,
//   y: 100
// }

// function setup() {
//   createCanvas(400, 300);
// }

// function draw() {
//   background(0);
//   ellipse(bubble.x, bubble.y, 16, 16);
// }